var searchData=
[
  ['newgamebutton_189',['newGameButton',['../class_game_project_1_1_graphics_1_1_assets.html#a98a04fb59927ce404d02521351dc831b',1,'GameProject::Graphics::Assets']]],
  ['notifyobservers_190',['notifyObservers',['../class_game_project_1_1_entities_1_1_player.html#a5d09b03eb25795b5130946da85563bf2',1,'GameProject.Entities.Player.notifyObservers()'],['../interface_game_project_1_1_maps_1_1_subject.html#aa709d192f078b85144b798e9913cbe7d',1,'GameProject.Maps.Subject.notifyObservers()']]]
];
