var searchData=
[
  ['width_641',['width',['../class_game_project_1_1_entities_1_1_entity.html#a4710100d177f4763d7aef9cdee8b908d',1,'GameProject.Entities.Entity.width()'],['../class_game_project_1_1_maps_1_1_map.html#a3db26b345aef58176c21edefd1540e6a',1,'GameProject.Maps.Map.width()'],['../class_game_project_1_1_user_interface_1_1_u_i_object.html#ae25367a91de39b4322656ba3d95b9b10',1,'GameProject.UserInterface.UIObject.width()']]],
  ['wndframe_642',['wndFrame',['../class_game_project_1_1_game_window_1_1_game_window.html#a50673449fa8594b5b0f8f601cd8458c0',1,'GameProject::GameWindow::GameWindow']]]
];
