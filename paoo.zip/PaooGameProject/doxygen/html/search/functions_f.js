var searchData=
[
  ['reflinks_514',['RefLinks',['../class_game_project_1_1_ref_links.html#af5c9fb53946336a6d70113e0aabac661',1,'GameProject::RefLinks']]],
  ['registerobserver_515',['registerObserver',['../class_game_project_1_1_entities_1_1_player.html#a57e16f487ac1dd6bd4cea4583e650d8a',1,'GameProject.Entities.Player.registerObserver()'],['../interface_game_project_1_1_maps_1_1_subject.html#a92962c737f751496c3ca2e06a7f02283',1,'GameProject.Maps.Subject.registerObserver()']]],
  ['removelife_516',['removeLife',['../class_game_project_1_1_entities_1_1_items_1_1_apple.html#a07be280603d6b60cd3351ab1cb5da80a',1,'GameProject.Entities.Items.Apple.removeLife()'],['../class_game_project_1_1_entities_1_1_items_1_1_bacon.html#ab3231139f237131a8bf2ce09940777ed',1,'GameProject.Entities.Items.Bacon.removeLife()'],['../class_game_project_1_1_entities_1_1_items_1_1_chocolate.html#af97784578ad656eddcd42565fdb4060a',1,'GameProject.Entities.Items.Chocolate.removeLife()'],['../class_game_project_1_1_entities_1_1_items_1_1_item.html#a2513a9bce8b7eb38a9cd76131513b43d',1,'GameProject.Entities.Items.Item.removeLife()'],['../class_game_project_1_1_entities_1_1_items_1_1_steak.html#a93ad36762e7f22a634957697b0689b80',1,'GameProject.Entities.Items.Steak.removeLife()'],['../class_game_project_1_1_entities_1_1_player.html#a691d63f2a57ee5e1a0542eda212eaed5',1,'GameProject.Entities.Player.removeLife()']]],
  ['removeobject_517',['removeObject',['../class_game_project_1_1_user_interface_1_1_u_i_manager.html#a1e713eff5d4f05a506c460e65c45f6dd',1,'GameProject::UserInterface::UIManager']]],
  ['reset_518',['reset',['../class_game_project_1_1_game.html#a161a0157cdf32100f132450ca3ef2d61',1,'GameProject::Game']]],
  ['resetpoints_519',['resetPoints',['../class_game_project_1_1_score_1_1_score.html#ace6bbdb7b1c7b78cd678db641d38c0f8',1,'GameProject::Score::Score']]],
  ['rocktile_520',['RockTile',['../class_game_project_1_1_tiles_1_1_rock_tile.html#a25d8634f74c46ad8e9b40b129a0ce4c9',1,'GameProject::Tiles::RockTile']]],
  ['run_521',['run',['../class_game_project_1_1_game.html#a68f7e4931e31b4aa62cbd3eb2701e371',1,'GameProject::Game']]]
];
