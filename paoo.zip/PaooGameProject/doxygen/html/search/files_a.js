var searchData=
[
  ['observer_2ejava_381',['Observer.java',['../_observer_8java.html',1,'']]]
];
