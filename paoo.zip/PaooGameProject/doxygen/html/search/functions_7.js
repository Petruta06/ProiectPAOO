var searchData=
[
  ['human_470',['Human',['../class_game_project_1_1_entities_1_1_human.html#aec8af5f10c7bd347dd2987c2cd7d7f1c',1,'GameProject::Entities::Human']]]
];
