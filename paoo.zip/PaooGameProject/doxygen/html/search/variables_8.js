var searchData=
[
  ['id_603',['id',['../class_game_project_1_1_tiles_1_1_tile.html#a493f08b11effc2244ac9fe7984564f23',1,'GameProject::Tiles::Tile']]],
  ['img_604',['img',['../class_game_project_1_1_tiles_1_1_tile.html#afc2689306aac4c933c16d111f128b948',1,'GameProject::Tiles::Tile']]],
  ['isactive_605',['isActive',['../class_game_project_1_1_entities_1_1_entity.html#a519c1b5708886a0090cb72817ca238a2',1,'GameProject::Entities::Entity']]]
];
