var searchData=
[
  ['observer_324',['Observer',['../interface_game_project_1_1_maps_1_1_observer.html',1,'GameProject::Maps']]]
];
